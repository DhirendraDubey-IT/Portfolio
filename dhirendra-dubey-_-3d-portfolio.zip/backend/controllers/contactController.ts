import { Request, Response, NextFunction } from 'express';
import { Contact } from '../models/Contact.ts';
import { isDbConnected } from '../config/database.ts';

// In-memory fallback storage
interface StoredMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  createdAt: Date;
  storage: 'mongodb' | 'memory';
}

const memoryStore: StoredMessage[] = [];

export const submitContact = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { name, email, subject, message } = req.body;

    // Field presence validation
    const errors: Record<string, string> = {};
    if (!name || typeof name !== 'string' || !name.trim()) {
      errors.name = 'Please provide your full name.';
    } else if (name.trim().length > 100) {
      errors.name = 'Name cannot exceed 100 characters.';
    }

    if (!email || typeof email !== 'string' || !email.trim()) {
      errors.email = 'Please provide your email address.';
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) {
        errors.email = 'Please provide a valid email format (e.g. name@domain.com).';
      }
    }

    if (!subject || typeof subject !== 'string' || !subject.trim()) {
      errors.subject = 'Please specify the subject of your inquiry.';
    } else if (subject.trim().length > 200) {
      errors.subject = 'Subject cannot exceed 200 characters.';
    }

    if (!message || typeof message !== 'string' || !message.trim()) {
      errors.message = 'Please include a message.';
    } else if (message.trim().length < 5) {
      errors.message = 'Message must be at least 5 characters.';
    } else if (message.trim().length > 5000) {
      errors.message = 'Message cannot exceed 5000 characters.';
    }

    if (Object.keys(errors).length > 0) {
      res.status(400).json({
        success: false,
        message: 'Validation failed. Please correct the specified fields.',
        errors,
      });
      return;
    }

    const trimmedName = name.trim();
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedSubject = subject.trim();
    const trimmedMessage = message.trim();

    let savedRecord;

    if (isDbConnected()) {
      try {
        const contactDoc = await Contact.create({
          name: trimmedName,
          email: trimmedEmail,
          subject: trimmedSubject,
          message: trimmedMessage,
          createdAt: new Date(),
        });
        savedRecord = {
          id: contactDoc._id.toString(),
          name: contactDoc.name,
          email: contactDoc.email,
          subject: contactDoc.subject,
          message: contactDoc.message,
          createdAt: contactDoc.createdAt,
          storage: 'mongodb' as const,
        };
      } catch (dbErr) {
        console.warn('[Contact Controller] Error writing to MongoDB, saving to memory fallback:', dbErr);
      }
    }

    if (!savedRecord) {
      const fallbackRecord: StoredMessage = {
        id: `mem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        name: trimmedName,
        email: trimmedEmail,
        subject: trimmedSubject,
        message: trimmedMessage,
        createdAt: new Date(),
        storage: 'memory',
      };
      memoryStore.unshift(fallbackRecord);
      // Keep recent 50
      if (memoryStore.length > 50) memoryStore.pop();
      savedRecord = fallbackRecord;
    }

    res.status(201).json({
      success: true,
      message: 'Thank you for reaching out! Your message has been received by Dhirendra.',
      data: {
        id: savedRecord.id,
        name: savedRecord.name,
        subject: savedRecord.subject,
        createdAt: savedRecord.createdAt,
      },
    });
  } catch (err) {
    next(err);
  }
};

export const getHealth = (_req: Request, res: Response) => {
  res.status(200).json({
    status: 'ok',
    database: isDbConnected() ? 'connected' : 'memory_fallback',
    timestamp: new Date().toISOString(),
  });
};

export const getMessages = async (_req: Request, res: Response, next: NextFunction) => {
  try {
    if (isDbConnected()) {
      const messages = await Contact.find().sort({ createdAt: -1 }).limit(20).lean();
      res.json({
        success: true,
        count: messages.length,
        source: 'mongodb',
        messages,
      });
      return;
    }

    res.json({
      success: true,
      count: memoryStore.length,
      source: 'memory_store',
      messages: memoryStore,
    });
  } catch (err) {
    next(err);
  }
};
