import { Router } from 'express';
import { submitContact, getHealth, getMessages } from '../controllers/contactController.ts';

const router = Router();

router.post('/contact', submitContact);
router.get('/contact/messages', getMessages);
router.get('/health', getHealth);

export default router;
