import React, { useState, useEffect } from 'react';
import { ThreeCanvas } from './components/ThreeCanvas.tsx';
import { LoadingScreen } from './components/LoadingScreen.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Hero } from './components/Hero.tsx';
import { AboutEducation } from './components/AboutEducation.tsx';
import { SkillsUniverse } from './components/SkillsUniverse.tsx';
import { Projects } from './components/Projects.tsx';
import { Experience } from './components/Experience.tsx';
import { AchievementsCertifications } from './components/AchievementsCertifications.tsx';
import { InterestsOrbit } from './components/InterestsOrbit.tsx';
import { ResumeSection } from './components/ResumeSection.tsx';
import { ResumeModal } from './components/ResumeModal.tsx';
import { ContactSection } from './components/ContactSection.tsx';
import { Footer } from './components/Footer.tsx';

export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);

  // Track active section during scroll
  useEffect(() => {
    const handleScroll = () => {
      const sections = [
        'home',
        'about',
        'skills',
        'projects',
        'experience',
        'achievements',
        'certifications',
        'contact',
      ];
      const scrollPosition = window.scrollY + 200;

      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDownloadResume = () => {
    // Triggers download of the resume document
    const link = document.createElement('a');
    link.href = '/resume-dhirendra-dubey.html';
    link.download = 'Dhirendra_Dubey_Resume.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="relative min-h-screen bg-[#07090e] text-slate-100 selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Short cinematic loading screen */}
      {!loaded && <LoadingScreen onComplete={() => setLoaded(true)} />}

      {/* Real Three.js 3D Background Universe */}
      <ThreeCanvas currentSection={activeSection} />

      {/* Floating Glass Navigation */}
      <Navbar
        activeSection={activeSection}
        onNavigate={scrollToSection}
        onOpenResumeModal={() => setIsResumeModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="relative z-10 space-y-8">
        <Hero
          onExploreWork={() => scrollToSection('projects')}
          onOpenResumeModal={() => setIsResumeModalOpen(true)}
          onDownloadResume={handleDownloadResume}
        />

        <AboutEducation />

        <SkillsUniverse />

        <Projects />

        <Experience />

        <AchievementsCertifications />

        <InterestsOrbit />

        <ResumeSection
          onViewResume={() => setIsResumeModalOpen(true)}
          onDownloadResume={handleDownloadResume}
        />

        <ContactSection />
      </main>

      {/* Footer */}
      <Footer onScrollToTop={() => window.scrollTo({ top: 0, behavior: 'smooth' })} />

      {/* In-app Resume View Modal */}
      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
        onDownload={handleDownloadResume}
      />
    </div>
  );
}
