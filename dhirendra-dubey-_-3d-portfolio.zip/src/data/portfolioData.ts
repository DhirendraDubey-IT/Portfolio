import portraitImg from '../assets/images/dhirendra_dubey_portrait_1790971142860.jpg';
import dataShieldImg from '../assets/images/data_shield_viz_1790971154545.jpg';
import threatDetectionImg from '../assets/images/threat_detection_viz_1790971166075.jpg';

export interface EducationItem {
  degree: string;
  institution: string;
  location?: string;
  status: string;
  period?: string;
}

export interface SkillCategory {
  category: string;
  skills: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  type: string;
  description: string;
  technologies: {
    frontend?: string[];
    backend?: string[];
    concepts?: string[];
  };
  image: string;
  status: string;
}

export interface ExperienceItem {
  role: string;
  company: string;
  duration: string;
  responsibilities: string[];
}

export interface CertificationItem {
  title: string;
  issuer: string;
  issueDate: string;
  credentialCode?: string;
}

export interface AchievementItem {
  title: string;
  level: string;
  highlight?: string;
}

export const portfolioData = {
  personal: {
    name: 'Dhirendra Dubey',
    title: 'B.Tech Information Technology | Technology & Business Enthusiast',
    heroTagline: 'B.Tech IT Student & Technology Enthusiast',
    location: 'Lucknow, Uttar Pradesh, India',
    email: 'dubeydhirendra434@gmail.com',
    linkedInUrl: 'https://www.linkedin.com/in/dhirendra-dubey-2aa9012a4',
    linkedInHandle: 'linkedin.com/in/dhirendra-dubey-2aa9012a4',
    description:
      'Technology enthusiast focused on learning, building practical solutions and exploring AI, cybersecurity and modern web technologies.',
    aboutStatement: "TECHNOLOGY IS NOT JUST WHAT I LEARN. IT'S WHAT I BUILD WITH.",
    aboutBio:
      'A dedicated 2nd-year B.Tech Information Technology student at SR Group of Institutions, Lucknow. Driven by an analytical mindset and deep curiosity for technology, artificial intelligence, cybersecurity, and modern web systems. Known for effective communication, team coordination, proactive problem solving, and a dedication to continuous technical and business learning.',
    careerObjective:
      'To begin my professional journey in a growth-oriented environment where I can apply my communication, coordination, problem-solving, and organizational skills to contribute effectively to the team while gaining practical industry experience and building my career in technology and business.',
    photoUrl: portraitImg,
    animatedKeywords: ['AI', 'CYBERSECURITY', 'PYTHON', 'WEB DEVELOPMENT', 'MACHINE LEARNING'],
  },

  education: [
    {
      degree: 'B.Tech — Information Technology',
      institution: 'SR Group of Institutions / SRGI',
      location: 'Lucknow (BKT), Uttar Pradesh',
      status: 'Currently 2nd Year',
      period: '2023 – Present',
    },
    {
      degree: 'Class 12 (Senior Secondary)',
      institution: 'Kachhwa Christian School (KCS)',
      location: 'Uttar Pradesh',
      status: 'Completed',
    },
    {
      degree: 'Class 10 (Secondary)',
      institution: 'Kachhwa Christian School (KCS)',
      location: 'Uttar Pradesh',
      status: 'Completed',
    },
  ] as EducationItem[],

  skills: [
    {
      category: 'PROGRAMMING',
      skills: ['Python', 'Data Structures'],
    },
    {
      category: 'WEB DEVELOPMENT',
      skills: ['HTML', 'CSS', 'JavaScript'],
    },
    {
      category: 'DATABASE',
      skills: [
        'MySQL',
        'SQL Queries',
        'CRUD Operations',
        'Python–MySQL Connectivity',
        'Basic Database Concepts',
      ],
    },
    {
      category: 'AI / CYBERSECURITY',
      skills: [
        'Machine Learning Fundamentals',
        'Phishing URL Detection',
        'Cybersecurity Fundamentals',
      ],
    },
    {
      category: 'TOOLS',
      skills: ['Visual Studio Code', 'Canva', 'Microsoft Office'],
    },
  ] as SkillCategory[],

  projects: [
    {
      id: 'data-shield-ai',
      title: 'DATA SHIELD AI',
      type: 'Academic Project — Ongoing',
      description: 'Technology-oriented project focused on data, privacy and security.',
      technologies: {
        frontend: ['HTML', 'CSS', 'JavaScript'],
        backend: ['Currently under development'],
      },
      image: dataShieldImg,
      status: 'In Development',
    },
    {
      id: 'phishing-url-detection',
      title: 'FAKE NEWS & PHISHING URL DETECTION',
      type: 'Practical ML Project',
      description:
        'Project related to identifying fake news and phishing URLs with exposure to machine-learning concepts through practical project implementation.',
      technologies: {
        concepts: ['Machine Learning', 'Threat Classification', 'Lexical Heuristics', 'Feature Extraction'],
      },
      image: threatDetectionImg,
      status: 'Prototype Deployed',
    },
  ] as ProjectItem[],

  experience: [
    {
      role: 'E-COMMERCE MANAGER',
      company: 'Zenith Marketing Agency',
      duration: '1 August – 1 September',
      responsibilities: [
        'Product research and evaluation',
        'Product listings',
        'Customer calling',
        'Customer coordination',
        'Customer follow-ups',
        'Customer relationship management',
        'Order follow-up until delivery',
        'Day-to-day e-commerce operations',
      ],
    },
    {
      role: 'CONTENT WRITER',
      company: 'InAmigos Foundation',
      duration: 'Volunteer / Foundation',
      responsibilities: [
        'Instagram content',
        'Social-media posts',
        'Content ideas',
        'Audience-appropriate written communication',
      ],
    },
  ] as ExperienceItem[],

  achievementsSummary: {
    awardsCount: '9+ Awards / Trophies',
    medalsCount: '6 Medals',
    certificatesCount: '10+ Certificates',
  },

  specificAchievements: [
    {
      title: 'Second Rank — Reasoning & Aptitude Test',
      level: 'College Level',
      highlight: 'Rank 2 across institution aptitude evaluation',
    },
    {
      title: 'Second Rank — College Hackathon',
      level: 'First Year',
      highlight: 'Awarded 2nd position in technical innovation hackathon',
    },
  ] as AchievementItem[],

  certifications: [
    {
      title: 'Introduction to Cybersecurity Awareness',
      issuer: 'HP LIFE',
      issueDate: '17 Oct 2024',
      credentialCode: 'HP-CYBER-2024',
    },
    {
      title: 'Resume Writing and Job Interviewing',
      issuer: 'HP LIFE',
      issueDate: '17 Oct 2024',
      credentialCode: 'HP-RESUME-2024',
    },
    {
      title: 'Customer Relationship Management',
      issuer: 'HP LIFE',
      issueDate: '17 Oct 2024',
      credentialCode: 'HP-CRM-2024',
    },
    {
      title: 'AI for Beginners',
      issuer: 'HP LIFE',
      issueDate: '31 Jul 2025',
      credentialCode: 'HP-AI-2025',
    },
  ] as CertificationItem[],

  interests: [
    {
      name: 'Coding',
      iconName: 'Code',
      description: 'Building logic, exploring algorithms, and automating practical tasks in Python and JavaScript.',
    },
    {
      name: 'Cooking',
      iconName: 'Utensils',
      description: 'Exploring precision and culinary creativity through methodical recipe preparation.',
    },
    {
      name: 'Reading',
      iconName: 'BookOpen',
      description: 'Reading tech publications, literature, self-development, and computing history.',
    },
    {
      name: 'Poetry & Article Writing',
      iconName: 'Feather',
      description: 'Expressing human perspectives, philosophical reflections, and technological articles through writing.',
    },
  ],

  languages: [
    { name: 'Hindi', proficiency: 'High Proficiency' },
    { name: 'English', proficiency: 'Intermediate' },
  ],
};
