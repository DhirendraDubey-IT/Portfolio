import React from 'react';
import { ArrowUp, Github, Linkedin, Mail } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

interface FooterProps {
  onScrollToTop: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onScrollToTop }) => {
  const { personal } = portfolioData;

  return (
    <footer className="relative z-10 border-t border-white/5 bg-[#05070b]/90 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
        
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-500/30 flex items-center justify-center font-display font-bold text-cyan-300 text-xs">
            DD
          </div>
          <div>
            <p className="text-xs font-mono font-medium text-slate-300">
              Dhirendra Dubey · Personal Portfolio
            </p>
            <p className="text-[11px] font-mono text-slate-500">
              B.Tech Information Technology · SRGI Lucknow
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-6 text-xs font-mono text-slate-400">
          <a
            href={`mailto:${personal.email}`}
            className="hover:text-cyan-300 transition-colors"
          >
            Email
          </a>
          <a
            href={personal.linkedInUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-cyan-300 transition-colors"
          >
            LinkedIn
          </a>
          <button
            onClick={onScrollToTop}
            className="flex items-center space-x-1.5 p-2 rounded-lg bg-slate-900 border border-white/10 hover:border-cyan-500/40 text-cyan-400 transition-all cursor-pointer"
            aria-label="Back to top"
          >
            <ArrowUp className="w-3.5 h-3.5" />
            <span className="text-[11px]">Top</span>
          </button>
        </div>

      </div>
    </footer>
  );
};
