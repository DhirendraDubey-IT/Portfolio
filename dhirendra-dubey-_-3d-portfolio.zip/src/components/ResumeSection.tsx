import React from 'react';
import { FileText, Eye, Download, Sparkles, CheckCircle2 } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

interface ResumeSectionProps {
  onViewResume: () => void;
  onDownloadResume: () => void;
}

export const ResumeSection: React.FC<ResumeSectionProps> = ({
  onViewResume,
  onDownloadResume,
}) => {
  const { personal, achievementsSummary } = portfolioData;

  return (
    <section id="resume" className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto">
        
        <div className="relative rounded-3xl p-8 sm:p-12 bg-gradient-to-r from-slate-900/90 via-slate-900/80 to-cyan-950/40 border border-cyan-500/30 backdrop-blur-xl shadow-2xl overflow-hidden">
          
          {/* Subtle glow orb */}
          <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            
            <div className="space-y-4 max-w-2xl">
              <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
                <FileText className="w-4 h-4" />
                <span>OFFICIAL DOSSIER</span>
              </div>

              <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
                MY RESUME
              </h2>

              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                Comprehensive overview of academic milestones at SRGI Lucknow, core technical proficiencies in Python and web technologies, e-commerce management experience, and verified HP LIFE certifications.
              </p>

              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-2">
                <span className="flex items-center space-x-1.5 text-cyan-300">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>2nd Year B.Tech IT</span>
                </span>
                <span>·</span>
                <span className="flex items-center space-x-1.5 text-cyan-300">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{achievementsSummary.awardsCount}</span>
                </span>
                <span>·</span>
                <span className="flex items-center space-x-1.5 text-cyan-300">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>4 HP LIFE Certifications</span>
                </span>
              </div>
            </div>

            {/* Action Buttons: VIEW RESUME & DOWNLOAD RESUME */}
            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
              <button
                onClick={onViewResume}
                className="inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider bg-slate-800 hover:bg-slate-700 text-white border border-white/10 hover:border-cyan-400 transition-all cursor-pointer shadow-lg hover:shadow-cyan-500/10"
              >
                <Eye className="w-4 h-4 text-cyan-400" />
                <span>VIEW RESUME</span>
              </button>

              <button
                onClick={onDownloadResume}
                className="inline-flex items-center justify-center space-x-2 px-6 py-3.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-semibold shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
              >
                <Download className="w-4 h-4 text-slate-950" />
                <span>DOWNLOAD RESUME</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
