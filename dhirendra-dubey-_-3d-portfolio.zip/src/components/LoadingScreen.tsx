import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [phase, setPhase] = useState<'initializing' | 'revealing' | 'complete'>('initializing');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Quick progress timer
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 15;
      });
    }, 90);

    const timer1 = setTimeout(() => {
      setPhase('revealing');
    }, 700);

    const timer2 = setTimeout(() => {
      setPhase('complete');
      onComplete();
    }, 1600);

    return () => {
      clearInterval(interval);
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {phase !== 'complete' && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#07090e] text-white"
        >
          {/* Subtle background radial aura */}
          <div className="absolute w-[450px] h-[450px] bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center text-center px-6">
            {phase === 'initializing' ? (
              <motion.div
                key="init"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
                className="flex flex-col items-center space-y-4"
              >
                <div className="flex items-center space-x-2">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span className="font-mono text-xs uppercase tracking-[0.25em] text-cyan-400 font-semibold">
                    INITIALIZING...
                  </span>
                </div>
                {/* Tech scanline bar */}
                <div className="w-48 h-1 bg-slate-800 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                    style={{ width: `${progress}%` }}
                    transition={{ ease: 'easeOut' }}
                  />
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="name"
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                className="flex flex-col items-center space-y-3"
              >
                <h1 className="text-3xl md:text-5xl font-extrabold tracking-wider font-display uppercase bg-gradient-to-r from-white via-slate-100 to-cyan-300 bg-clip-text text-transparent">
                  DHIRENDRA DUBEY
                </h1>
                <p className="font-mono text-xs tracking-[0.2em] text-cyan-400/90 uppercase">
                  Personal Digital Universe
                </p>
              </motion.div>
            )}

            <button
              onClick={() => {
                setPhase('complete');
                onComplete();
              }}
              className="mt-12 text-[11px] font-mono tracking-widest text-slate-500 hover:text-cyan-400 transition-colors uppercase underline underline-offset-4"
            >
              Skip
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
