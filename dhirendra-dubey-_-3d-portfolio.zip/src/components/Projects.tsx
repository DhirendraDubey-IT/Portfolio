import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Lock,
  Eye,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Sliders,
  Layers,
  Sparkles,
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const Projects: React.FC = () => {
  const { projects } = portfolioData;

  // Project 01: Digital Shield Visualization Interactive State
  const [shieldActive, setShieldActive] = useState(true);
  const [activeLayer, setActiveLayer] = useState<'privacy' | 'encryption' | 'integrity'>('privacy');

  // Project 02: URL Threat Detection Live Pipeline State
  const [testUrl, setTestUrl] = useState('http://secure-login-account-update-verify.top/auth');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<{
    url: string;
    threatLevel: 'HIGH_RISK_SUSPICIOUS' | 'SAFE_PATTERN';
    checks: {
      excessiveSubdomains: boolean;
      suspiciousKeywords: boolean;
      highEntropy: boolean;
      nonStandardTld: boolean;
    };
    verdict: string;
  } | null>(null);

  const handleRunUrlAnalysis = (targetUrl: string = testUrl) => {
    if (!targetUrl.trim()) return;
    setAnalyzing(true);
    setAnalysisResult(null);

    setTimeout(() => {
      const lower = targetUrl.toLowerCase();
      const hasSuspiciousKeywords =
        lower.includes('login') ||
        lower.includes('verify') ||
        lower.includes('secure') ||
        lower.includes('account') ||
        lower.includes('paypal') ||
        lower.includes('update');

      const parts = targetUrl.split('/');
      const domainPart = parts[2] || parts[0];
      const hasManyDots = (domainPart.match(/\./g) || []).length >= 3;
      const hasNonStandardTld =
        lower.endsWith('.top') ||
        lower.endsWith('.xyz') ||
        lower.endsWith('.click') ||
        lower.endsWith('.tk') ||
        lower.endsWith('.live');
      const hasSpecialHyphens = (domainPart.match(/-/g) || []).length >= 2;

      const isPhishingPattern =
        (hasSuspiciousKeywords && (hasManyDots || hasNonStandardTld || hasSpecialHyphens)) ||
        targetUrl.startsWith('http://');

      setAnalysisResult({
        url: targetUrl,
        threatLevel: isPhishingPattern ? 'HIGH_RISK_SUSPICIOUS' : 'SAFE_PATTERN',
        checks: {
          excessiveSubdomains: hasManyDots,
          suspiciousKeywords: hasSuspiciousKeywords,
          highEntropy: hasSpecialHyphens,
          nonStandardTld: hasNonStandardTld,
        },
        verdict: isPhishingPattern
          ? 'Potential Phishing Signature Detected via Lexical Pattern Heuristics'
          : 'Standard Clean Structure Detected in URL Feature Extraction',
      });
      setAnalyzing(false);
    }, 600);
  };

  return (
    <section id="projects" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <Layers className="w-4 h-4" />
            <span>03 · TECHNICAL INITIATIVES</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
            FEATURED PROJECTS
          </h2>

          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Practical academic implementations bridging systems programming, data privacy architectures, and machine-learning threat classification.
          </p>
        </div>

        {/* Project 01: DATA SHIELD AI */}
        <div className="rounded-3xl bg-slate-900/60 border border-white/5 overflow-hidden backdrop-blur-md hover:border-cyan-500/20 transition-all shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10">
            
            {/* Visual / Shield Interactive Column */}
            <div className="lg:col-span-6 space-y-4">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] bg-slate-950 border border-white/10 group">
                <img
                  src={projects[0].image}
                  alt="Data Shield AI Visualizer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />

                {/* Digital Shield Overlay Controls */}
                <div className="absolute inset-x-4 bottom-4 p-4 rounded-xl bg-slate-950/85 backdrop-blur-md border border-cyan-500/30 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${shieldActive ? 'bg-cyan-500/20 text-cyan-400' : 'bg-slate-800 text-slate-500'}`}>
                      <Lock className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-xs font-mono font-semibold text-white">
                        DIGITAL SHIELD STATE
                      </p>
                      <p className="text-[11px] font-mono text-cyan-400">
                        {shieldActive ? 'PROTECTION ACTIVE · LAYER VERIFIED' : 'STANDBY MODE'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShieldActive(!shieldActive)}
                    className="px-3 py-1.5 rounded-lg text-xs font-mono font-medium tracking-wider uppercase bg-slate-800 hover:bg-slate-700 text-white border border-white/10 cursor-pointer transition-colors"
                  >
                    Toggle
                  </button>
                </div>
              </div>

              {/* Shield Layers Switcher */}
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'privacy', label: 'Privacy Core' },
                  { id: 'encryption', label: 'Crypto Guard' },
                  { id: 'integrity', label: 'Data Sentinel' },
                ].map((layer) => (
                  <button
                    key={layer.id}
                    onClick={() => setActiveLayer(layer.id as any)}
                    className={`py-2 px-3 rounded-lg text-xs font-mono tracking-wider uppercase transition-all cursor-pointer ${
                      activeLayer === layer.id
                        ? 'bg-cyan-950/60 border border-cyan-500/40 text-cyan-300'
                        : 'bg-slate-900/60 border border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {layer.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Project Details */}
            <div className="lg:col-span-6 space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono text-cyan-400 tracking-wider uppercase">
                  PROJECT 01 · {projects[0].type}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-white uppercase tracking-tight">
                  {projects[0].title}
                </h3>
              </div>

              <p className="text-slate-300 text-sm leading-relaxed">
                {projects[0].description}
              </p>

              {/* Tech Stack Breakdown */}
              <div className="space-y-3 pt-2">
                <div>
                  <span className="text-xs font-mono text-slate-400 block mb-1.5 uppercase">
                    Frontend Architecture:
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {projects[0].technologies.frontend?.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 rounded-md text-xs font-mono bg-slate-800/80 border border-white/5 text-cyan-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-xs font-mono text-slate-400 block mb-1.5 uppercase">
                    Backend Status:
                  </span>
                  <div className="p-3 rounded-xl bg-slate-900/80 border border-dashed border-cyan-500/30 text-xs font-mono text-slate-300 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                    <span>Currently under development — exploring secure API orchestration.</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/40 border border-white/5 text-xs text-slate-400 leading-relaxed">
                <strong className="text-slate-200">Objective:</strong> Architecting an end-to-end user privacy surface that prevents unauthorized credential telemetry and secures data transmission against common client-side interception vectors.
              </div>
            </div>

          </div>
        </div>

        {/* Project 02: FAKE NEWS & PHISHING URL DETECTION */}
        <div className="rounded-3xl bg-slate-900/60 border border-white/5 overflow-hidden backdrop-blur-md hover:border-cyan-500/20 transition-all shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center p-6 sm:p-10">
            
            {/* Left Column: Project Overview */}
            <div className="lg:col-span-5 space-y-6">
              <div className="space-y-2">
                <span className="text-xs font-mono text-cyan-400 tracking-wider uppercase">
                  PROJECT 02 · {projects[1].type}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold font-display text-white uppercase tracking-tight">
                  {projects[1].title}
                </h3>
              </div>

              <p className="text-slate-300 text-sm leading-relaxed">
                {projects[1].description}
              </p>

              <div className="rounded-2xl overflow-hidden border border-white/10 aspect-[4/3] bg-slate-950">
                <img
                  src={projects[1].image}
                  alt="Threat Detection Visualizer"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div>
                <span className="text-xs font-mono text-slate-400 block mb-1.5 uppercase">
                  Core ML & Security Concepts:
                </span>
                <div className="flex flex-wrap gap-2">
                  {projects[1].technologies.concepts?.map((c) => (
                    <span
                      key={c}
                      className="px-2.5 py-1 rounded-md text-xs font-mono bg-slate-800/80 border border-white/5 text-slate-200"
                    >
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Live Interactive Pipeline (URL INPUT -> ANALYSIS -> THREAT DETECTION -> RESULT) */}
            <div className="lg:col-span-7 space-y-6 p-6 sm:p-8 rounded-2xl bg-[#090d18] border border-cyan-500/20">
              
              {/* Pipeline Step Header */}
              <div className="flex items-center justify-between pb-4 border-b border-white/10 text-xs font-mono">
                <span className="text-cyan-400 font-semibold uppercase tracking-wider">
                  PRACTICAL IMPLEMENTATION WORKFLOW
                </span>
                <span className="text-slate-500">
                  URL INPUT → ANALYSIS → THREAT DETECTION → RESULT
                </span>
              </div>

              {/* Step 1: URL Input */}
              <div className="space-y-2">
                <label className="text-xs font-mono text-slate-300 uppercase flex items-center justify-between">
                  <span>1. URL Input Test Bench:</span>
                  <span className="text-[11px] text-slate-500">Type or choose below</span>
                </label>

                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="text"
                      value={testUrl}
                      onChange={(e) => setTestUrl(e.target.value)}
                      placeholder="e.g. https://your-domain.com"
                      className="w-full pl-3 pr-8 py-2.5 rounded-lg bg-slate-900 border border-white/10 text-slate-200 text-xs font-mono focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                  <button
                    onClick={() => handleRunUrlAnalysis(testUrl)}
                    disabled={analyzing}
                    className="px-4 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
                  >
                    {analyzing ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Search className="w-3.5 h-3.5" />
                    )}
                    <span>Analyze</span>
                  </button>
                </div>

                {/* Preset URL Quick Selectors */}
                <div className="flex flex-wrap gap-2 pt-1 text-[11px] font-mono">
                  <span className="text-slate-500">Presets:</span>
                  <button
                    onClick={() => {
                      const u = 'http://secure-login-account-update-verify.top/auth';
                      setTestUrl(u);
                      handleRunUrlAnalysis(u);
                    }}
                    className="text-amber-400 hover:underline cursor-pointer"
                  >
                    [Suspicious Pattern]
                  </button>
                  <button
                    onClick={() => {
                      const u = 'https://linkedin.com/in/dhirendra-dubey-2aa9012a4';
                      setTestUrl(u);
                      handleRunUrlAnalysis(u);
                    }}
                    className="text-cyan-400 hover:underline cursor-pointer"
                  >
                    [Clean Pattern]
                  </button>
                </div>
              </div>

              {/* Step 2 & 3: Feature Extraction & Threat Analysis Display */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-white/5 space-y-3">
                <span className="text-xs font-mono text-slate-400 uppercase block">
                  2 & 3. Feature Extraction & Threat Detection:
                </span>

                {analyzing ? (
                  <div className="py-6 flex flex-col items-center justify-center space-y-2">
                    <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
                    <span className="text-xs font-mono text-cyan-300">
                      TOKENIZING URL · EXTRACTING LEXICAL FEATURES...
                    </span>
                  </div>
                ) : analysisResult ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2.5 rounded bg-slate-950 border border-white/5 flex items-center justify-between">
                        <span className="text-slate-400">Keyword Spoofing:</span>
                        <span className={analysisResult.checks.suspiciousKeywords ? 'text-amber-400' : 'text-emerald-400'}>
                          {analysisResult.checks.suspiciousKeywords ? 'DETECTED' : 'CLEAR'}
                        </span>
                      </div>
                      <div className="p-2.5 rounded bg-slate-950 border border-white/5 flex items-center justify-between">
                        <span className="text-slate-400">Subdomain Depth:</span>
                        <span className={analysisResult.checks.excessiveSubdomains ? 'text-amber-400' : 'text-emerald-400'}>
                          {analysisResult.checks.excessiveSubdomains ? 'ELEVATED' : 'STANDARD'}
                        </span>
                      </div>
                      <div className="p-2.5 rounded bg-slate-950 border border-white/5 flex items-center justify-between">
                        <span className="text-slate-400">Entropy / Hyphens:</span>
                        <span className={analysisResult.checks.highEntropy ? 'text-amber-400' : 'text-emerald-400'}>
                          {analysisResult.checks.highEntropy ? 'ABNORMAL' : 'NORMAL'}
                        </span>
                      </div>
                      <div className="p-2.5 rounded bg-slate-950 border border-white/5 flex items-center justify-between">
                        <span className="text-slate-400">Suspicious TLD:</span>
                        <span className={analysisResult.checks.nonStandardTld ? 'text-amber-400' : 'text-emerald-400'}>
                          {analysisResult.checks.nonStandardTld ? 'HIGH-RISK' : 'SAFE'}
                        </span>
                      </div>
                    </div>

                    {/* Step 4: Final Result */}
                    <div
                      className={`p-3.5 rounded-xl border flex items-start space-x-3 ${
                        analysisResult.threatLevel === 'HIGH_RISK_SUSPICIOUS'
                          ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                          : 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                      }`}
                    >
                      {analysisResult.threatLevel === 'HIGH_RISK_SUSPICIOUS' ? (
                        <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                      ) : (
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                      )}
                      <div>
                        <p className="text-xs font-mono font-bold uppercase tracking-wider">
                          RESULT: {analysisResult.verdict}
                        </p>
                        <p className="text-[11px] text-slate-300 mt-1">
                          Evaluated against URL lexical heuristics without synthetic assumptions. Demonstrates applied ML classification pipeline.
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs font-mono text-slate-500 py-3 text-center">
                    Enter a URL and click "Analyze" to inspect features.
                  </p>
                )}
              </div>

            </div>

          </div>
        </div>

      </div>
    </section>
  );
};
