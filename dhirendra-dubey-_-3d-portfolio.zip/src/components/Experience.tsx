import React from 'react';
import { Briefcase, ShoppingBag, PenTool, Calendar, ArrowRight, Check } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const Experience: React.FC = () => {
  const { experience } = portfolioData;

  const getCompanyIcon = (role: string) => {
    if (role.includes('E-COMMERCE')) return ShoppingBag;
    return PenTool;
  };

  return (
    <section id="experience" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <Briefcase className="w-4 h-4" />
            <span>04 · OPERATIONAL BACKGROUND</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
            EXPERIENCE
          </h2>

          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Hands-on professional and foundational exposure across customer lifecycle operations, digital e-commerce coordination, and audience-targeted communications.
          </p>
        </div>

        {/* Cinematic Vertical 3D Timeline */}
        <div className="relative pl-6 sm:pl-10 border-l-2 border-cyan-500/25 space-y-12">
          {experience.map((exp, index) => {
            const Icon = getCompanyIcon(exp.role);
            return (
              <div key={exp.role} className="relative group">
                {/* Luminous Timeline Node */}
                <div className="absolute -left-[31px] sm:-left-[47px] top-4 w-5 h-5 rounded-full bg-slate-900 border-2 border-cyan-400 group-hover:scale-125 transition-all shadow-lg shadow-cyan-500/30 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-300" />
                </div>

                <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/60 border border-white/5 hover:border-cyan-500/30 backdrop-blur-md transition-all duration-300 shadow-xl group-hover:shadow-cyan-950/40">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6">
                    <div className="flex items-center space-x-3.5">
                      <div className="w-11 h-11 rounded-2xl bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="text-xl font-display font-bold text-white uppercase tracking-tight">
                          {exp.role}
                        </h3>
                        <p className="text-sm font-medium text-cyan-300">
                          {exp.company}
                        </p>
                      </div>
                    </div>

                    <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-800/80 border border-white/5 text-xs font-mono text-slate-300 self-start md:self-auto">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{exp.duration}</span>
                    </div>
                  </div>

                  {/* Responsibilities list */}
                  <div className="space-y-3">
                    <p className="text-xs font-mono uppercase tracking-wider text-slate-400">
                      KEY DELIVERABLES & RESPONSIBILITIES:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {exp.responsibilities.map((resp) => (
                        <div
                          key={resp}
                          className="flex items-start space-x-2.5 p-2.5 rounded-xl bg-slate-950/40 border border-white/5 text-xs text-slate-300"
                        >
                          <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{resp}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
