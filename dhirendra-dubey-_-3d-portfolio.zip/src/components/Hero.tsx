import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowDown, Download, ShieldCheck, Sparkles, Terminal } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

interface HeroProps {
  onExploreWork: () => void;
  onOpenResumeModal: () => void;
  onDownloadResume: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreWork,
  onOpenResumeModal,
  onDownloadResume,
}) => {
  const { personal } = portfolioData;
  const [keywordIndex, setKeywordIndex] = useState(0);

  // Holographic card 3D tilt tracking
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const cardRef = useRef<HTMLDivElement>(null);

  // Keyword cycling
  useEffect(() => {
    const timer = setInterval(() => {
      setKeywordIndex((prev) => (prev + 1) % personal.animatedKeywords.length);
    }, 2400);
    return () => clearInterval(timer);
  }, [personal.animatedKeywords.length]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    // Map to degrees
    setTilt({
      x: -(y / (rect.height / 2)) * 12,
      y: (x / (rect.width / 2)) * 12,
    });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden"
    >
      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center z-10">
        
        {/* LEFT COLUMN: Hero Copy & Actions */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-6 text-left">
          
          {/* Subtle top indicator */}
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping inline-block" />
            <span>HELLO, I'M</span>
          </div>

          {/* Main Name Heading */}
          <div className="space-y-1">
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight font-display uppercase leading-none text-white">
              DHIRENDRA
              <br />
              <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">
                DUBEY
              </span>
            </h1>

            <p className="text-lg sm:text-2xl font-display font-medium text-slate-300 pt-2">
              {personal.heroTagline}
            </p>
          </div>

          {/* Animated Tech Keywords ticker */}
          <div className="h-8 flex items-center space-x-3 text-sm sm:text-base font-mono">
            <span className="text-slate-500 font-normal">FOCUS //</span>
            <div className="relative h-7 overflow-hidden w-64">
              <AnimatePresence mode="wait">
                <motion.span
                  key={personal.animatedKeywords[keywordIndex]}
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: -20, opacity: 0 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="absolute inset-0 flex items-center font-bold tracking-wider text-cyan-300"
                >
                  {personal.animatedKeywords[keywordIndex]}
                </motion.span>
              </AnimatePresence>
            </div>
          </div>

          {/* Description */}
          <p className="text-slate-400 text-sm sm:text-base max-w-xl leading-relaxed">
            {personal.description}
          </p>

          {/* Interactive CTAs */}
          <div className="flex flex-wrap gap-4 pt-4">
            <button
              onClick={onExploreWork}
              className="inline-flex items-center space-x-2 px-6 py-3.5 rounded-lg text-sm font-semibold tracking-wide uppercase bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all cursor-pointer transform hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>EXPLORE MY WORK</span>
              <ArrowDown className="w-4 h-4 animate-bounce" />
            </button>

            <button
              onClick={onDownloadResume}
              className="inline-flex items-center space-x-2 px-6 py-3.5 rounded-lg text-sm font-semibold tracking-wide uppercase bg-slate-900/80 hover:bg-slate-800/90 text-slate-200 border border-white/10 hover:border-cyan-500/40 transition-all cursor-pointer shadow-md hover:shadow-cyan-500/10"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>DOWNLOAD RESUME</span>
            </button>
          </div>

          {/* Micro badges / Quick status */}
          <div className="pt-6 flex flex-wrap items-center gap-6 text-xs text-slate-400 border-t border-white/5">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Cybersecurity & AI Focus</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center space-x-2">
              <Terminal className="w-4 h-4 text-blue-400" />
              <span>SRGI Lucknow · 2nd Year IT</span>
            </div>
            <span className="text-slate-600">·</span>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span>Active Builder</span>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Holographic 3D Photo Container */}
        <div className="lg:col-span-5 flex justify-center items-center">
          <div
            ref={cardRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            style={{
              perspective: '1000px',
            }}
            className="relative w-full max-w-[380px] sm:max-w-[420px] aspect-square flex items-center justify-center cursor-pointer select-none"
          >
            {/* 3D Tilted Card Container */}
            <div
              style={{
                transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)`,
                transition: 'transform 0.15s ease-out',
                transformStyle: 'preserve-3d',
              }}
              className="relative w-[300px] sm:w-[340px] aspect-square rounded-3xl p-3 bg-gradient-to-b from-white/10 via-cyan-500/5 to-transparent border border-cyan-500/30 backdrop-blur-xl shadow-2xl shadow-cyan-950/60"
            >
              {/* Outer Orbital Rings */}
              <div
                className="absolute -inset-6 rounded-full border border-cyan-500/20 pointer-events-none animate-spin"
                style={{ animationDuration: '32s' }}
              />
              <div
                className="absolute -inset-12 rounded-full border border-dashed border-violet-500/20 pointer-events-none animate-spin"
                style={{ animationDuration: '48s', animationDirection: 'reverse' }}
              />

              {/* Glowing Corner Bracket Nodes */}
              <div className="absolute top-1 left-1 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
              <div className="absolute top-1 right-1 w-3 h-3 border-t-2 border-r-2 border-cyan-400" />
              <div className="absolute bottom-1 left-1 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />
              <div className="absolute bottom-1 right-1 w-3 h-3 border-b-2 border-r-2 border-cyan-400" />

              {/* Holographic HUD Badge on Top */}
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-[#0a0f1d] border border-cyan-500/40 text-[10px] font-mono tracking-widest text-cyan-300 shadow-md">
                PORTFOLIO CORE
              </div>

              {/* Photo Mask Container */}
              <div className="relative w-full h-full rounded-2xl overflow-hidden bg-slate-900 border border-white/10 group">
                <img
                  src={personal.photoUrl}
                  alt="Dhirendra Dubey - Professional Portrait"
                  className="w-full h-full object-cover object-top transition-transform duration-500 group-hover:scale-105"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />

                {/* Subtle Holographic Glass Scanline Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#07090e] via-transparent to-cyan-500/10 opacity-70 pointer-events-none" />

                {/* Soft Rim Light Indicator */}
                <div className="absolute bottom-3 left-3 right-3 p-2.5 rounded-xl bg-slate-950/75 backdrop-blur-md border border-white/10 flex items-center justify-between text-xs">
                  <div>
                    <p className="font-semibold text-white tracking-wide">Dhirendra Dubey</p>
                    <p className="text-[11px] text-cyan-400 font-mono">B.Tech IT · SRGI Lucknow</p>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-[10px] text-slate-300 font-mono">AVAILABLE</span>
                  </div>
                </div>
              </div>

              {/* Floating Node Orbs */}
              <div className="absolute -right-3 top-1/4 w-3 h-3 rounded-full bg-cyan-400 shadow-lg shadow-cyan-400 animate-pulse" />
              <div className="absolute -left-3 bottom-1/4 w-3 h-3 rounded-full bg-violet-400 shadow-lg shadow-violet-400 animate-pulse" />
            </div>
          </div>
        </div>

      </div>

      {/* Bottom Scroll Guide */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-1 text-slate-500 text-xs font-mono uppercase tracking-widest pointer-events-none">
        <ArrowDown className="w-4 h-4 animate-bounce text-cyan-400/80" />
      </div>
    </section>
  );
};
