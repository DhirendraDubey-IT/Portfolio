import React, { useState } from 'react';
import { Code, Utensils, BookOpen, Feather, Orbit, Sparkles } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const InterestsOrbit: React.FC = () => {
  const { interests } = portfolioData;
  const [selectedInterest, setSelectedInterest] = useState<number>(0);

  const icons = [Code, Utensils, BookOpen, Feather];

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <Orbit className="w-4 h-4" />
            <span>07 · PERSONAL PURSUITS</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
            INTERESTS & ORBIT
          </h2>

          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Multidisciplinary passions shaping analytical problem solving, creative synthesis, and structured craftsmanship.
          </p>
        </div>

        {/* 3D Orbit Visualizer & Card System */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left: Interactive Orbital System */}
          <div className="lg:col-span-6 flex justify-center items-center py-6">
            <div className="relative w-72 sm:w-88 aspect-square flex items-center justify-center">
              
              {/* Outer Orbit Guide Ring */}
              <div className="absolute inset-0 rounded-full border border-dashed border-cyan-500/25 animate-spin" style={{ animationDuration: '45s' }} />
              
              {/* Inner Orbit Ring */}
              <div className="absolute inset-10 rounded-full border border-white/10 pointer-events-none" />

              {/* Central Nucleus */}
              <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-cyan-500/20 via-blue-600/30 to-violet-600/30 border border-cyan-400/50 backdrop-blur-md flex flex-col items-center justify-center text-center p-2 shadow-xl shadow-cyan-500/20">
                <Sparkles className="w-5 h-5 text-cyan-300 animate-pulse" />
                <span className="text-[10px] font-mono tracking-widest text-cyan-200 mt-1 uppercase font-bold">
                  FOCUS
                </span>
              </div>

              {/* 4 Orbital Satellites (Coding, Cooking, Reading, Poetry) */}
              {interests.map((item, idx) => {
                const Icon = icons[idx];
                const isSelected = selectedInterest === idx;
                
                // Position calculations around the circle
                const angle = (idx * (360 / interests.length) * Math.PI) / 180;
                const radius = 125; // in px
                const x = Math.cos(angle) * radius;
                const y = Math.sin(angle) * radius;

                return (
                  <button
                    key={item.name}
                    onClick={() => setSelectedInterest(idx)}
                    style={{
                      transform: `translate(${x}px, ${y}px)`,
                    }}
                    className={`absolute w-14 h-14 rounded-2xl flex flex-col items-center justify-center transition-all duration-300 cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500 text-slate-950 shadow-xl shadow-cyan-400/40 scale-110 border-2 border-white'
                        : 'bg-slate-900/90 hover:bg-slate-800 text-slate-300 border border-white/10 hover:border-cyan-400/50'
                    }`}
                    aria-label={`Select ${item.name}`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="text-[9px] font-mono font-bold uppercase mt-0.5">
                      {item.name.split(' ')[0]}
                    </span>
                  </button>
                );
              })}

            </div>
          </div>

          {/* Right: Selected Interest Detail Panel */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-8 rounded-3xl bg-slate-900/70 border border-cyan-500/30 backdrop-blur-xl shadow-2xl relative overflow-hidden">
              <div className="flex items-center space-x-3 mb-4">
                {React.createElement(icons[selectedInterest], {
                  className: 'w-7 h-7 text-cyan-400',
                })}
                <h3 className="text-2xl font-display font-bold text-white uppercase tracking-wide">
                  {interests[selectedInterest].name}
                </h3>
              </div>

              <p className="text-slate-300 text-base leading-relaxed">
                {interests[selectedInterest].description}
              </p>

              {/* Fast selector buttons */}
              <div className="pt-6 mt-6 border-t border-white/5 flex flex-wrap gap-2">
                {interests.map((it, idx) => (
                  <button
                    key={it.name}
                    onClick={() => setSelectedInterest(idx)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider transition-all cursor-pointer ${
                      selectedInterest === idx
                        ? 'bg-cyan-950/80 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-800/60 text-slate-400 hover:text-white border border-transparent'
                    }`}
                  >
                    {it.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
