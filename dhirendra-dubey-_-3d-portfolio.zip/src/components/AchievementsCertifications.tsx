import React, { useState } from 'react';
import {
  Trophy,
  Medal,
  Award,
  ShieldCheck,
  CheckCircle,
  ExternalLink,
  Sparkles,
  Calendar,
  Building,
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const AchievementsCertifications: React.FC = () => {
  const { achievementsSummary, specificAchievements, certifications } = portfolioData;

  const statPillars = [
    {
      label: 'Awards / Trophies',
      count: '9+',
      icon: Trophy,
      color: 'from-amber-500/20 to-yellow-500/5',
      borderColor: 'border-amber-500/30',
      iconColor: 'text-amber-400',
    },
    {
      label: 'Medals Earned',
      count: '6',
      icon: Medal,
      color: 'from-cyan-500/20 to-blue-500/5',
      borderColor: 'border-cyan-500/30',
      iconColor: 'text-cyan-400',
    },
    {
      label: 'Certificates',
      count: '10+',
      icon: Award,
      color: 'from-violet-500/20 to-purple-500/5',
      borderColor: 'border-violet-500/30',
      iconColor: 'text-violet-400',
    },
  ];

  return (
    <section id="achievements" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-20">
        
        {/* ACHIEVEMENTS BLOCK */}
        <div className="space-y-12">
          <div className="space-y-4">
            <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
              <Trophy className="w-4 h-4" />
              <span>05 · DISTINCTIONS & HONORS</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
              ACHIEVEMENTS
            </h2>

            <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
              Demonstrated competitive excellence in analytical assessments, institutional hackathons, and academic evaluations.
            </p>
          </div>

          {/* Metric Pillars */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {statPillars.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className={`p-6 sm:p-8 rounded-3xl bg-gradient-to-b ${stat.color} bg-slate-900/60 border ${stat.borderColor} backdrop-blur-md relative overflow-hidden group hover:scale-[1.02] transition-all duration-300 shadow-xl`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-3xl sm:text-5xl font-extrabold font-display text-white tracking-tight tabular-nums">
                      {stat.count}
                    </span>
                    <div className="w-12 h-12 rounded-2xl bg-slate-950/60 border border-white/10 flex items-center justify-center group-hover:rotate-6 transition-transform">
                      <Icon className={`w-6 h-6 ${stat.iconColor}`} />
                    </div>
                  </div>

                  <p className="font-display font-semibold text-slate-200 text-base">
                    {stat.label}
                  </p>
                  <p className="text-xs text-slate-400 font-mono mt-1">
                    Recognized Institutional & College Milestones
                  </p>
                </div>
              );
            })}
          </div>

          {/* Specific Achievements Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            {specificAchievements.map((item, idx) => (
              <div
                key={item.title}
                className="p-6 rounded-2xl bg-slate-900/60 border border-white/10 hover:border-cyan-500/40 transition-all backdrop-blur-md flex items-start space-x-4 shadow-lg group"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 group-hover:scale-105 transition-transform">
                  <Medal className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 font-semibold">
                      HONOR
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      {item.level}
                    </span>
                  </div>
                  <h3 className="text-base font-display font-bold text-white pt-1">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {item.highlight}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* CERTIFICATIONS BLOCK */}
        <div id="certifications" className="pt-8 space-y-12">
          <div className="space-y-4">
            <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
              <ShieldCheck className="w-4 h-4" />
              <span>06 · CREDENTIAL REPOSITORY</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
              CERTIFICATIONS
            </h2>

            <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
              Official industry certifications issued by HP LIFE validating foundational training in cybersecurity, artificial intelligence, and corporate communications.
            </p>
          </div>

          {/* Holographic Certificate Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {certifications.map((cert) => (
              <div
                key={cert.title}
                className="relative p-6 sm:p-7 rounded-3xl bg-gradient-to-br from-slate-900/90 via-slate-900/60 to-cyan-950/20 border border-cyan-500/20 hover:border-cyan-400/50 backdrop-blur-xl transition-all duration-300 shadow-xl group hover:-translate-y-1"
              >
                {/* Holographic Corner Accent */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-cyan-500/10 via-transparent to-transparent pointer-events-none rounded-tr-3xl" />

                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-9 h-9 rounded-xl bg-cyan-950/60 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                        <Building className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="font-mono text-xs font-bold text-cyan-300 tracking-wider">
                          {cert.issuer}
                        </span>
                        <p className="text-[10px] text-slate-500 font-mono">GLOBAL CREDENTIAL</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5 px-2.5 py-1 rounded-full bg-emerald-950/40 border border-emerald-500/30 text-emerald-400 text-[11px] font-mono">
                      <CheckCircle className="w-3 h-3" />
                      <span>VERIFIED</span>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-display font-bold text-white group-hover:text-cyan-200 transition-colors leading-snug">
                      {cert.title}
                    </h3>
                  </div>

                  <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs font-mono text-slate-400">
                    <div className="flex items-center space-x-1.5">
                      <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Issued: {cert.issueDate}</span>
                    </div>
                    {cert.credentialCode && (
                      <span className="text-[11px] text-slate-500">
                        {cert.credentialCode}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
