import React from 'react';
import { X, Download, Printer, ExternalLink, Mail, MapPin, Linkedin, Briefcase, GraduationCap, Award, Shield } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownload: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose, onDownload }) => {
  if (!isOpen) return null;

  const { personal, education, experience, projects, skills, certifications, specificAchievements, achievementsSummary, languages } = portfolioData;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#0f1422] border border-cyan-500/40 rounded-3xl shadow-2xl text-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-900 border-b border-white/10 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400" />
            <h3 className="font-display font-bold text-white text-base tracking-wide uppercase">
              Curriculum Vitae — Dhirendra Dubey
            </h3>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
              title="Print Resume"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onDownload}
              className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-mono text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
              title="Close modal"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Resume Content Body */}
        <div className="p-6 sm:p-10 overflow-y-auto space-y-8 bg-[#090d18] text-slate-300 print:bg-white print:text-black">
          
          {/* Top Profile Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 pb-6 border-b border-white/10 print:border-black">
            <div className="space-y-1">
              <h1 className="text-2xl sm:text-3xl font-display font-extrabold uppercase text-white print:text-black">
                {personal.name}
              </h1>
              <p className="text-cyan-400 font-medium text-sm print:text-blue-700">
                {personal.title}
              </p>
              <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400 pt-2 print:text-gray-700">
                <span className="flex items-center space-x-1">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400" />
                  <span>{personal.location}</span>
                </span>
                <span className="flex items-center space-x-1">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <a href={`mailto:${personal.email}`} className="hover:underline text-cyan-300">
                    {personal.email}
                  </a>
                </span>
                <span className="flex items-center space-x-1">
                  <Linkedin className="w-3.5 h-3.5 text-cyan-400" />
                  <a
                    href={personal.linkedInUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:underline text-cyan-300"
                  >
                    {personal.linkedInHandle}
                  </a>
                </span>
              </div>
            </div>

            {/* Profile Photo Thumbnail */}
            <div className="w-20 h-20 rounded-xl overflow-hidden border border-cyan-500/40 shrink-0">
              <img
                src={personal.photoUrl}
                alt={personal.name}
                className="w-full h-full object-cover object-top"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>

          {/* Career Objective */}
          <div className="space-y-2">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
              CAREER OBJECTIVE
            </h2>
            <p className="text-xs sm:text-sm leading-relaxed text-slate-300 print:text-black">
              {personal.careerObjective}
            </p>
          </div>

          {/* Education */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
              EDUCATION
            </h2>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.degree} className="flex justify-between items-start text-xs sm:text-sm">
                  <div>
                    <p className="font-bold text-white print:text-black">{edu.degree}</p>
                    <p className="text-slate-400">{edu.institution} {edu.location ? `· ${edu.location}` : ''}</p>
                  </div>
                  <span className="font-mono text-cyan-400 text-xs">{edu.status}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Professional Experience */}
          <div className="space-y-4">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
              PROFESSIONAL EXPERIENCE
            </h2>
            <div className="space-y-4">
              {experience.map((exp) => (
                <div key={exp.role} className="space-y-1.5">
                  <div className="flex justify-between items-start text-xs sm:text-sm">
                    <div>
                      <span className="font-bold text-white uppercase print:text-black">{exp.role}</span>
                      <p className="text-cyan-300 text-xs">{exp.company}</p>
                    </div>
                    <span className="font-mono text-slate-400 text-xs">{exp.duration}</span>
                  </div>
                  <ul className="list-disc list-inside text-xs text-slate-400 space-y-1">
                    {exp.responsibilities.map((r) => (
                      <li key={r}>{r}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Projects */}
          <div className="space-y-4">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
              PROJECTS
            </h2>
            <div className="space-y-3">
              {projects.map((proj) => (
                <div key={proj.id} className="text-xs sm:text-sm space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-white print:text-black">{proj.title}</span>
                    <span className="text-xs font-mono text-cyan-400">{proj.type}</span>
                  </div>
                  <p className="text-slate-400 text-xs">{proj.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Grid */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
              TECHNICAL SKILLS
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {skills.map((s) => (
                <div key={s.category} className="space-y-1">
                  <span className="font-bold text-slate-300">{s.category}:</span>
                  <p className="text-slate-400 font-mono">{s.skills.join(', ')}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications & Achievements */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div className="space-y-2">
              <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
                CERTIFICATIONS
              </h2>
              <ul className="text-xs space-y-1.5 text-slate-300">
                {certifications.map((c) => (
                  <li key={c.title}>
                    <strong>{c.title}</strong> — {c.issuer} ({c.issueDate})
                  </li>
                ))}
              </ul>
            </div>

            <div className="space-y-2">
              <h2 className="text-xs font-mono font-bold tracking-widest uppercase text-cyan-400 border-b border-cyan-500/20 pb-1">
                ACHIEVEMENTS
              </h2>
              <ul className="text-xs space-y-1.5 text-slate-300">
                <li>{achievementsSummary.awardsCount} · {achievementsSummary.medalsCount} · {achievementsSummary.certificatesCount}</li>
                {specificAchievements.map((a) => (
                  <li key={a.title}>
                    {a.title} ({a.level})
                  </li>
                ))}
              </ul>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
