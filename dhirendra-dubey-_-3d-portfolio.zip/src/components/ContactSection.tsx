import React, { useState } from 'react';
import {
  Mail,
  Linkedin,
  MapPin,
  Send,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  ArrowUpRight,
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const ContactSection: React.FC = () => {
  const { personal } = portfolioData;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!formData.name.trim()) errors.name = 'Please provide your full name.';
    if (!formData.email.trim()) {
      errors.email = 'Please provide your email address.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    if (!formData.subject.trim()) errors.subject = 'Please provide a subject.';
    if (!formData.message.trim()) {
      errors.message = 'Please enter your message.';
    } else if (formData.message.trim().length < 5) {
      errors.message = 'Message must be at least 5 characters.';
    }
    return errors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const errors = validate();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    setFormErrors({});
    setSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setStatusMessage({
          type: 'success',
          text: data.message || 'Your message has been sent successfully to Dhirendra!',
        });
        setFormData({ name: '', email: '', subject: '', message: '' });
      } else {
        setStatusMessage({
          type: 'error',
          text: data.message || 'Unable to deliver message. Please try again or email directly.',
        });
        if (data.errors) {
          setFormErrors(data.errors);
        }
      }
    } catch (err) {
      setStatusMessage({
        type: 'error',
        text: 'Network error communicating with the contact service. Please try again.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section id="contact" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Cinematic Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>08 · CONNECTION PORTAL</span>
          </div>

          <h2 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold font-display uppercase tracking-tight text-white leading-none">
            LET'S BUILD
            <br />
            SOMETHING
            <br />
            <span className="bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">
              MEANINGFUL.
            </span>
          </h2>
        </div>

        {/* Contact Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Info & Quick Action Buttons */}
          <div className="lg:col-span-5 space-y-8">
            <div className="p-8 rounded-3xl bg-slate-900/70 border border-white/5 backdrop-blur-xl shadow-xl space-y-6">
              <div className="space-y-1">
                <h3 className="text-xl font-display font-bold text-white uppercase">
                  {personal.name}
                </h3>
                <p className="text-sm text-cyan-400 font-mono">
                  {personal.title}
                </p>
              </div>

              <div className="space-y-4 text-xs font-mono text-slate-300">
                <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-950/60 border border-white/5">
                  <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{personal.location}</span>
                </div>

                <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-950/60 border border-white/5">
                  <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
                  <a href={`mailto:${personal.email}`} className="hover:text-cyan-300 transition-colors">
                    {personal.email}
                  </a>
                </div>

                <div className="flex items-center space-x-3 p-3 rounded-xl bg-slate-950/60 border border-white/5">
                  <Linkedin className="w-4 h-4 text-cyan-400 shrink-0" />
                  <a
                    href={personal.linkedInUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-cyan-300 transition-colors flex items-center space-x-1"
                  >
                    <span>{personal.linkedInHandle}</span>
                    <ArrowUpRight className="w-3 h-3 text-cyan-400 opacity-60" />
                  </a>
                </div>
              </div>

              {/* Direct Buttons: EMAIL ME & CONNECT ON LINKEDIN */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <a
                  href={`mailto:${personal.email}`}
                  className="flex-1 inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-cyan-500/20 text-center"
                >
                  <Mail className="w-4 h-4" />
                  <span>EMAIL ME</span>
                </a>

                <a
                  href={personal.linkedInUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 inline-flex items-center justify-center space-x-2 px-5 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400 font-mono text-xs font-bold uppercase tracking-wider transition-all text-center"
                >
                  <Linkedin className="w-4 h-4" />
                  <span>CONNECT ON LINKEDIN</span>
                </a>
              </div>
            </div>

            {/* Response Pledge Box */}
            <div className="p-5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 text-xs text-slate-300 space-y-2">
              <p className="font-mono text-cyan-400 font-bold uppercase">
                COMMUNICATION POLICY:
              </p>
              <p className="leading-relaxed">
                Open to discussions regarding technical internships, collaborative hackathons, AI/cybersecurity student research, and full-stack software initiatives.
              </p>
            </div>
          </div>

          {/* Right Column: Functional Contact Form */}
          <div className="lg:col-span-7">
            <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/80 border border-cyan-500/30 backdrop-blur-xl shadow-2xl space-y-6">
              <div className="space-y-1">
                <h3 className="text-xl font-display font-bold text-white uppercase tracking-wide">
                  Send a Direct Message
                </h3>
                <p className="text-xs font-mono text-slate-400">
                  Transmits directly to Express API backend and stores to database.
                </p>
              </div>

              {/* Status Alert Banner */}
              {statusMessage && (
                <div
                  className={`p-4 rounded-xl border flex items-start space-x-3 text-xs ${
                    statusMessage.type === 'success'
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                      : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
                  }`}
                >
                  {statusMessage.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  )}
                  <span>{statusMessage.text}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Name Field */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono uppercase text-slate-300">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="e.g. John Doe"
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border ${
                        formErrors.name ? 'border-rose-500' : 'border-white/10 focus:border-cyan-400'
                      } text-slate-100 text-sm focus:outline-none transition-colors`}
                    />
                    {formErrors.name && (
                      <p className="text-[11px] font-mono text-rose-400">{formErrors.name}</p>
                    )}
                  </div>

                  {/* Email Field */}
                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono uppercase text-slate-300">
                      Your Email *
                    </label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="e.g. john@example.com"
                      className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border ${
                        formErrors.email ? 'border-rose-500' : 'border-white/10 focus:border-cyan-400'
                      } text-slate-100 text-sm focus:outline-none transition-colors`}
                    />
                    {formErrors.email && (
                      <p className="text-[11px] font-mono text-rose-400">{formErrors.email}</p>
                    )}
                  </div>
                </div>

                {/* Subject Field */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-mono uppercase text-slate-300">
                    Subject *
                  </label>
                  <input
                    type="text"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="e.g. Project Inquiry / Opportunity"
                    className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border ${
                      formErrors.subject ? 'border-rose-500' : 'border-white/10 focus:border-cyan-400'
                    } text-slate-100 text-sm focus:outline-none transition-colors`}
                  />
                  {formErrors.subject && (
                    <p className="text-[11px] font-mono text-rose-400">{formErrors.subject}</p>
                  )}
                </div>

                {/* Message Field */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-mono uppercase text-slate-300">
                    Message *
                  </label>
                  <textarea
                    rows={4}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Write your message here..."
                    className={`w-full px-4 py-2.5 rounded-xl bg-slate-950 border ${
                      formErrors.message ? 'border-rose-500' : 'border-white/10 focus:border-cyan-400'
                    } text-slate-100 text-sm focus:outline-none transition-colors resize-none`}
                  />
                  {formErrors.message && (
                    <p className="text-[11px] font-mono text-rose-400">{formErrors.message}</p>
                  )}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-cyan-500/25 flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>DISPATCHING MESSAGE...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>SUBMIT MESSAGE</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
