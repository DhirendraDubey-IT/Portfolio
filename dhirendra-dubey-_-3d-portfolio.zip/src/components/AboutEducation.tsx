import React from 'react';
import {
  GraduationCap,
  Cpu,
  Shield,
  Code2,
  Users,
  Compass,
  CheckCircle2,
  Languages,
} from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const AboutEducation: React.FC = () => {
  const { personal, education, languages } = portfolioData;

  const coreStrengths = [
    {
      title: 'AI & Machine Learning',
      desc: 'Exploring foundational machine learning paradigms and practical security classifiers.',
      icon: Cpu,
      color: 'text-cyan-400',
    },
    {
      title: 'Cybersecurity & Privacy',
      desc: 'Focusing on threat surface reduction, phishing vector detection, and cryptographic basics.',
      icon: Shield,
      color: 'text-blue-400',
    },
    {
      title: 'Web & Systems Logic',
      desc: 'Developing frontends with modern HTML/CSS/JS and integrating Python backends with MySQL.',
      icon: Code2,
      color: 'text-sky-400',
    },
    {
      title: 'Coordination & Communication',
      desc: 'Proven client communication, audience-targeted writing, and collaborative project management.',
      icon: Users,
      color: 'text-violet-400',
    },
  ];

  return (
    <section id="about" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-20">
        
        {/* Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
            <span>01 · IDENTITY & VISION</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
            ABOUT ME
          </h2>

          <div className="max-w-4xl p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-cyan-950/30 border border-cyan-500/20 backdrop-blur-md shadow-xl">
            <p className="font-mono text-xs uppercase tracking-widest text-cyan-400 mb-2">
              CORE PHILOSOPHY
            </p>
            <blockquote className="text-xl sm:text-3xl font-display font-bold uppercase tracking-wide text-white leading-tight">
              "{personal.aboutStatement}"
            </blockquote>
          </div>
        </div>

        {/* Narrative & 3D Info Cards Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Biography & Career Objective */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 rounded-2xl bg-slate-900/60 border border-white/5 backdrop-blur-md space-y-4">
              <h3 className="text-lg font-display font-semibold text-white flex items-center space-x-2">
                <Compass className="w-5 h-5 text-cyan-400" />
                <span>Background & Direction</span>
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed">
                {personal.aboutBio}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900/60 border border-white/5 backdrop-blur-md space-y-3">
              <h3 className="text-sm font-mono uppercase tracking-wider text-cyan-400">
                CAREER OBJECTIVE
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed italic">
                "{personal.careerObjective}"
              </p>
            </div>

            {/* Languages section */}
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-white/5 backdrop-blur-md">
              <div className="flex items-center space-x-2 mb-3">
                <Languages className="w-4 h-4 text-cyan-400" />
                <h3 className="text-xs font-mono uppercase tracking-widest text-slate-300">
                  LANGUAGES
                </h3>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {languages.map((lang) => (
                  <div key={lang.name} className="p-3 rounded-xl bg-slate-800/40 border border-white/5">
                    <p className="text-sm font-semibold text-white">{lang.name}</p>
                    <p className="text-xs text-cyan-400/90 font-mono mt-0.5">{lang.proficiency}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: 3D Info Pillars */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {coreStrengths.map((strength) => {
              const Icon = strength.icon;
              return (
                <div
                  key={strength.title}
                  className="p-5 rounded-2xl bg-slate-900/50 border border-white/5 hover:border-cyan-500/30 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-slate-800/80 border border-white/10 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                    <Icon className={`w-5 h-5 ${strength.color}`} />
                  </div>
                  <h4 className="text-base font-display font-semibold text-white mb-1.5">
                    {strength.title}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {strength.desc}
                  </p>
                </div>
              );
            })}
          </div>

        </div>

        {/* EDUCATION SECTION: Cinematic Timeline */}
        <div className="pt-8 space-y-8">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
              <GraduationCap className="w-4 h-4" />
              <span>ACADEMIC TRAJECTORY</span>
            </div>
            <h3 className="text-2xl sm:text-4xl font-extrabold font-display uppercase tracking-tight text-white">
              EDUCATION
            </h3>
          </div>

          <div className="relative pl-6 sm:pl-8 border-l-2 border-cyan-500/30 space-y-8">
            {education.map((item, index) => (
              <div key={item.degree} className="relative group">
                {/* Luminous Node on timeline */}
                <div className="absolute -left-[31px] sm:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-slate-900 border-2 border-cyan-400 group-hover:scale-125 group-hover:border-cyan-300 transition-all shadow-md shadow-cyan-500/30 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                </div>

                <div className="p-5 sm:p-6 rounded-2xl bg-slate-900/70 border border-white/5 hover:border-cyan-500/30 transition-all duration-300 backdrop-blur-md">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <h4 className="text-lg font-display font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {item.degree}
                    </h4>
                    <span className="text-xs font-mono text-cyan-400/90 tracking-wider uppercase px-2.5 py-0.5 rounded-md bg-cyan-950/60 border border-cyan-500/20 self-start sm:self-auto">
                      {item.status}
                    </span>
                  </div>

                  <p className="text-sm font-medium text-slate-300">
                    {item.institution}
                  </p>
                  
                  {item.location && (
                    <p className="text-xs text-slate-500 font-mono mt-1">
                      {item.location} {item.period ? `· ${item.period}` : ''}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
