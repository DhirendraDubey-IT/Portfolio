import React, { useState } from 'react';
import { Terminal, Database, Shield, Wrench, Globe2, Sparkles, Layers } from 'lucide-react';
import { portfolioData } from '../data/portfolioData.ts';

export const SkillsUniverse: React.FC = () => {
  const { skills } = portfolioData;
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [selectedSkill, setSelectedSkill] = useState<string | null>(null);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'PROGRAMMING':
        return Terminal;
      case 'WEB DEVELOPMENT':
        return Globe2;
      case 'DATABASE':
        return Database;
      case 'AI / CYBERSECURITY':
        return Shield;
      case 'TOOLS':
        return Wrench;
      default:
        return Layers;
    }
  };

  const categories = ['ALL', ...skills.map((s) => s.category)];

  const displayedCategories =
    activeCategory === 'ALL'
      ? skills
      : skills.filter((s) => s.category === activeCategory);

  return (
    <section id="skills" className="py-24 px-4 sm:px-6 lg:px-8 relative z-10">
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Section Header */}
        <div className="space-y-4">
          <div className="inline-flex items-center space-x-2 text-cyan-400 font-mono text-xs uppercase tracking-widest">
            <Sparkles className="w-4 h-4" />
            <span>02 · KNOWLEDGE MATRIX</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-extrabold font-display uppercase tracking-tight text-white">
            SKILL UNIVERSE
          </h2>

          <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
            Organized cluster of core competencies spanning algorithmic programming, relational data architectures, artificial intelligence, and defensive cybersecurity concepts.
          </p>
        </div>

        {/* Category Filter Controls */}
        <div className="flex flex-wrap items-center gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-white/5 backdrop-blur-md max-w-fit">
          {categories.map((cat) => {
            const isSelected = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => {
                  setActiveCategory(cat);
                  setSelectedSkill(null);
                }}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono tracking-wider uppercase transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* Skill Clusters Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedCategories.map((group) => {
            const Icon = getCategoryIcon(group.category);
            return (
              <div
                key={group.category}
                className="p-6 rounded-2xl bg-slate-900/60 border border-white/5 hover:border-cyan-500/30 transition-all duration-300 backdrop-blur-md group hover:shadow-xl hover:shadow-cyan-950/30 flex flex-col justify-between"
              >
                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-center text-cyan-400 group-hover:scale-105 transition-transform">
                        <Icon className="w-5 h-5" />
                      </div>
                      <h3 className="font-display font-bold text-sm tracking-wider text-white uppercase">
                        {group.category}
                      </h3>
                    </div>
                    <span className="text-[11px] font-mono text-slate-500">
                      {group.skills.length} MODULES
                    </span>
                  </div>

                  {/* Skills Nodes */}
                  <div className="flex flex-wrap gap-2 pt-2">
                    {group.skills.map((skill) => {
                      const isHighlighted = selectedSkill === skill;
                      return (
                        <button
                          key={skill}
                          onClick={() => setSelectedSkill(selectedSkill === skill ? null : skill)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-medium tracking-wide transition-all cursor-pointer text-left ${
                            isHighlighted
                              ? 'bg-cyan-400 text-slate-950 shadow-md shadow-cyan-400/30 font-semibold'
                              : 'bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/5 hover:border-cyan-500/30'
                          }`}
                        >
                          {skill}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-white/5 flex items-center justify-between text-[11px] font-mono text-slate-500">
                  <span>Core Domain Module</span>
                  <span className="text-cyan-400/80">Active Stack</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Skill Detail Callout */}
        {selectedSkill && (
          <div className="p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/40 text-xs font-mono text-cyan-300 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              <span>ACTIVE FOCUS: <strong>{selectedSkill}</strong> — Applied in academic projects and technical implementations.</span>
            </div>
            <button
              onClick={() => setSelectedSkill(null)}
              className="text-slate-400 hover:text-white underline cursor-pointer"
            >
              Close
            </button>
          </div>
        )}

      </div>
    </section>
  );
};
